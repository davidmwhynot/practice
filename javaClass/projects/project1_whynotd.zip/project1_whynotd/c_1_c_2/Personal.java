/*

	File Name:
	Personal.java

	Author:
	David Whynot

	Date Created:
	2/9/18

	Description:
	#3 on pages 123-124

	Type:
	console

*/



public class Personal {
	public static void main(String[] args) {
		// INTRO
		System.out.println("\n\t Personal\n\t David Whynot\n\n\n");

		// MAIN
		// display
		System.out.println("Name:\t\tDavid Whynot\n" +
		"Address:\t488 Horton Road\n\t\tMuskegon, MI\n\t\t49445\n" +
		"Phone Number:\t(231)343-8583\n" +
		"Major:\t\tComputer Science");
	}
}
