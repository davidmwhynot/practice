/*

	File Name:
	ShipCost.java

	Author:
	David Whynot

	Date Created:
	4/30/18

	Type:
	gui

*/

public interface ShipCost {
	double calculateShipCost(int pounds);
}
